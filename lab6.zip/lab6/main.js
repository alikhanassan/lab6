// Task: Write a function that returns the product of three given numbers.
function multiplyThreeNumbers(num1, num2, num3) {
  return num1 * num2 * num3;
}

console.log(multiplyThreeNumbers(2, 3, 4));
console.log(multiplyThreeNumbers(-1, 5, 10));

// Task: Write a function that returns the greatest among the given three numbers.
function findGreatest(num1, num2, num3) {
  let greatest = num1;
  if (num2 > greatest) {
    greatest = num2;
  }
  if (num3 > greatest) {
    greatest = num3;
  }
  return greatest;
}

console.log(findGreatest(5, 3, 8));
console.log(findGreatest(4, 5, 21));

// Task: Write a function to check whether two given numbers are equal or not.
function checkEqual(num1, num2) {
  return num1 === num2;
}

console.log(checkEqual(2, 3));
console.log(checkEqual(-1, -1));

